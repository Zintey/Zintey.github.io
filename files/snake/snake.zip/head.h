#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;

const int MAXN = 1010;
//const mx[] = {0, 0, -1, 1};
//const my[] = {1, -1, 0, 0};

struct Snake {
	int x, y;
} snake[MAXN] = {2, 2}, head;
int L = 0, R = 0, len = 1, dir = 4;

int Map[200][200];

struct Game{
	int speed;
	bool over;
	Game(int a = 1, bool b = 0) : speed(a), over(b) {}
} game;

typedef struct Frame
{
    COORD position[2];
    int flag;
}Frame;

void SetPos(COORD a)
{
    HANDLE out=GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(out, a);
}

void SetPos(int i, int j)
{
    COORD pos={i, j};
    SetPos(pos);
}

void SetPos(int i, int j, char c)
{
    COORD pos={i, j};
    SetPos(pos);
	putchar(c);
}

void kColor(int color)
{
    /*
    color ==  1 -> blue
              2 -> green
              4 -> red
              7 -> white
    */
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | color);

}

void HideCursor() // ?�����ع��
{
	CONSOLE_CURSOR_INFO cursor_info = {1, 0};  // ��?��ֵΪ0��?���ع�� 
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
//�����ͽṹ�嶼��windows.h�ж��塣
}

int randint(int l, int r)
{
	return (rand() % (r - l + 1)) + l;
}
