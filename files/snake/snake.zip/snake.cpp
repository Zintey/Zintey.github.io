#include "head.h" 
using namespace std;
int iswrite, N = 16, M = 44;
int souce, cnt;

void entrance_get_kb()
{
	while(!game.over)
	{
		if(_kbhit())
		{
			char c = getch (), k = 'X';
			switch(c)
			{
				case 'w':
				case 'W':
					if(dir == 2 && len > 1) break;
					dir = 1;
					k = '^';
					break;
				case 's':
				case 'S':
					if(dir == 1 && len > 1) break;
					dir = 2;
					k = 'V';
					break;
				case 'a':
				case 'A':
					if(dir == 4 && len > 1) break;
					dir = 3;
					k = '<'; 
					break;
				case 'd':
				case 'D':
					if(dir == 3 && len > 1) break;
					dir = 4;
					k = '>';
					break;
			}
			while(_kbhit()) c = getch();
			while(iswrite)Sleep(game.speed);
			iswrite = 1;
			SetPos(M / 2, N - 1, k);
			iswrite = 0;
		}
	}
}

bool check()
{
	int x = head.x, y = head.y;
	if (Map[y][x] > 0)
		return 0;
	return 1;
}

void GAMEOVER()
{
	kColor(4);
	SetPos(snake[R].x, snake[R].y, 'O');
	game.over = 1;
	Sleep(300);
	system("cls");
	cout << "Gmae Over!!!" << endl;
	cout << "Souce => " << souce << endl;
	fstream f;
	f.open("maxsouce.sc");
	int num;
	f >> num;
	if (souce > num)
	{
		cout << "�¼�¼!!!\n\n\n";
		ofstream ff;
		ff.open("maxsouce.sc");
		ff << souce << endl;
		ff.close();
	}
	else
	{
		cout << "��ʷ��¼��" << num << "\n\n\n";
	}
	f.close();
	system("pause"); 
	exit(0);
}

void print()
{
	while(iswrite)Sleep(10);	iswrite = 1;
	if(head.x == snake[R].x && head.y == snake[R].y)
		return (void) (iswrite = 0);
	int x = snake[L].x, y = snake[L].y;
	SetPos(x, y, '\b');
	SetPos(x, y, ' ');
	Map[y][x] = 0;
	L++;
	x = head.x, y = head.y;
	SetPos(x, y, 'O');
	snake[++R] = head;
	if(!check())
		return (void)(iswrite = 0, GAMEOVER());
	if(Map[y][x] < 0)
	{
		souce += -1 * Map[y][x];
		Map[y][x] = 0;
		SetPos((M - 4) / 2, N, '$');
		cnt++;
		printf("%4d", souce);
	}
	Map[y][x] = 3;
	if (cnt >= min (len, 5))
	{
		cnt = 0;
		len++;
		L--;
		x = snake[L].x, y = snake[L].y;
		SetPos(x, y, 'O');
		Map[y][x] = 3;
	}
	iswrite = 0; 
}

void entrance_main()
{
	head = snake[0];
	while(!game.over)
	{
		print();
	}
}

void init()
{
	srand(time(NULL));
	system("title Snake");//����cmd���ڱ���
	system("mode con cols=61 lines=30");//���ڿ��ȸ߶�
	cout << "Speed(ms):";
	cin >> game.speed;
	system("cls");
	for (int i = 3; i >= 1; i--)
	{
		cout << i;
		Sleep (500);
		cout << '\b';
	}
	system ("cls");
	for (int i = 1; i < N - 1; i++)
//	{	
		Map[i][0] = Map[i][M - 1] = 2;
//		SetPos(0, i + 1, '|');
//		SetPos(M - 1, i + 1, '|');
//	}
	for (int j = 0; j < M; j++)
//	{
		Map[0][j] = Map[N - 1][j] = 1;	
//		SetPos(0, j + 1, '-');
//		SetPos(N - 1, j + 1, '-');
//	}
	for (int i = 0; i < N; i++, printf("\n"))
		for (int j = 0; j < M; j++)
		{
//			putchar(Map[i][j] + '0'); 
			if (Map[i][j] == 1)
				putchar('_');
			else if (Map[i][j] == 2)
				putchar('|');
			else
				putchar(' ');
		}
	    SetPos((M - 4) / 2, N, '$');
		printf("%4d", souce);
}

void entrance_do()
{
	while(!game.over)
	{
		Sleep(game.speed);
		Snake tmp = head;
		switch(dir)
		{
			case 1:
				head.y = snake[R].y - 1;
				break;
			case 2:
				head.y = snake[R].y + 1;
				break;
			case 3:
				head.x = snake[R].x - 1;
				break;
			case 4:
				head.x = snake[R].x + 1;
				break;
		}
	}
}

void entrance_creat_souce()
{
	srand(time(NULL));
	int x = 0, y = 0;
	while(!game.over)
	{
		Map[y][x] = 0;
		while(iswrite)Sleep(10);
		iswrite = 1;
		SetPos(x, y, '\b');
		SetPos(x, y, ' ');
		iswrite = 0;
		
		Sleep(game.speed * randint(0, 10));
		
		x = randint(1, M - 1), y = randint(3, N - 1);
		while(Map[y][x] > 0) x = randint(1, M - 1), y = randint(1, N - 1);
		Map[y][x] = -1 * len * (randint(0, 1) == 0 ? 1 : 2);
		while(iswrite)Sleep(10);
		iswrite = 1;
		SetPos(x, y, '$');
		iswrite = 0;
		Sleep(game.speed * randint(25, 40) * randint(1, 2));
		
	}
}

signed main()
{
	init(); 
	HideCursor();
	thread get_kb(entrance_get_kb);
	thread doing(entrance_do);
	thread creat_souce(entrance_creat_souce);
	entrance_main();
	get_kb.join();
	doing.join();
	return 0; 
}
